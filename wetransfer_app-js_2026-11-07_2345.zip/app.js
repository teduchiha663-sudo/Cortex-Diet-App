const meals = {
  yogurt: { name: "Greek yogurt bowl", icon: "◉", calories: 420, protein: 28, carbs: 54, fat: 10, fiber: 7, sugar: 20 },
  quinoa: { name: "Chicken & quinoa", icon: "✳", calories: 610, protein: 46, carbs: 58, fat: 18, fiber: 8, sugar: 7 },
  lentil: { name: "Lentil soup", icon: "◒", calories: 390, protein: 22, carbs: 58, fat: 8, fiber: 15, sugar: 8 },
  salmon: { name: "Salmon plate", icon: "⌁", calories: 570, protein: 38, carbs: 44, fat: 24, fiber: 9, sugar: 6 },
  toast: { name: "Avocado toast", icon: "◩", calories: 360, protein: 14, carbs: 42, fat: 18, fiber: 10, sugar: 3 },
  smoothie: { name: "Protein smoothie", icon: "◍", calories: 330, protein: 32, carbs: 38, fat: 7, fiber: 6, sugar: 18 },
};

const goalDefaults = {
  muscle: { label: "Build muscle", calories: 2400, protein: 140, mealCalories: 600, mealProtein: 35, weights: [0.25, 0.45, 0.2, 0.1] },
  weight: { label: "Lose weight", calories: 1800, protein: 120, mealCalories: 450, mealProtein: 30, weights: [0.4, 0.3, 0.2, 0.1] },
  gain: { label: "Gain weight", calories: 2300, protein: 110, mealCalories: 575, mealProtein: 28, weights: [0.3, 0.3, 0.25, 0.15] },
  balance: { label: "Feel balanced", calories: 2000, protein: 100, mealCalories: 500, mealProtein: 25, weights: [0.3, 0.25, 0.3, 0.15] },
};

const storageKeys = { profile: "good-measure-profile-v1", meals: "good-measure-meals-v1", foods: "good-measure-foods-v1" };
const profileDefaults = { goal: "balance", calories: 2000, protein: 100, age: "", height: "", weight: "", sex: "unspecified", activity: 1.2, training: 0, mealsPerDay: 3, diet: "anything", bodyGoal: "maintain", allergies: [] };
let usdaApiKey = "DEMO_KEY";
const $ = (selector) => document.querySelector(selector);
const mealForm = $("#meal-form");
const mealNameInput = $("#meal-name");
const mealBaseInput = $("#meal-base");
const portionOutput = $("#portion-count");
let portions = 1;
let toastTimer;
let currentFoods = [];
let assistantApiKey = "";
let assistantHistory = [];
let localAssistantTurns = [];
let lastFoodQuery = "";
let lastFoodType = "";
let nextFoodPage = 0;
let foodSearchCount = readFoodSearchCount();
let manualMealEntry = false;
let pendingMealMatches = [];

function readStorage(key, fallback) {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch {
    return fallback;
  }
}

function saveStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    showToast("Browser storage is unavailable. Your changes won't persist after closing this page.");
  }
}

function readFoodSearchCount() {
  try {
    const count = Number(sessionStorage.getItem("good-measure-usda-searches") || 0);
    return Number.isFinite(count) ? Math.max(0, count) : 0;
  } catch {
    return 0;
  }
}

let profile = { ...profileDefaults, ...readStorage(storageKeys.profile, {}) };
if (!goalDefaults[profile.goal]) profile.goal = "balance";
profile.calories = validNumber(profile.calories, 800, 6000, goalDefaults[profile.goal].calories);
profile.protein = validNumber(profile.protein, 20, 400, goalDefaults[profile.goal].protein);
profile.mealsPerDay = validNumber(profile.mealsPerDay, 2, 6, 3);
profile.allergies = Array.isArray(profile.allergies) ? profile.allergies.filter((item) => typeof item === "string") : [];
let customFoods = readStorage(storageKeys.foods, {});
if (!customFoods || typeof customFoods !== "object" || Array.isArray(customFoods)) customFoods = {};
let loggedMeals = readStorage(storageKeys.meals, []);
if (!Array.isArray(loggedMeals)) loggedMeals = [];
loggedMeals = loggedMeals.filter((meal) => meal && (meals[meal.base] || customFoods[meal.base]) && typeof meal.title === "string").map((meal) => ({
  id: typeof meal.id === "string" ? meal.id : crypto.randomUUID(),
  base: meal.base,
  title: meal.title.slice(0, 48),
  portions: validNumber(meal.portions, 0.5, 5, 1),
}));

function validNumber(value, min, max, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
}

function getFood(id) {
  return meals[id] || customFoods[id];
}

function getTotals(base, count = 1) {
  const meal = getFood(base) || meals.yogurt;
  return Object.fromEntries(["calories", "protein", "carbs", "fat", "fiber", "sugar", "sodium"].map((key) => [key, (meal[key] || 0) * count]));
}

function formatNutrient(value) {
  return String(Math.round(value * 10) / 10);
}

function getScore(base, count = 1) {
  const target = goalDefaults[profile.goal];
  const mealCalories = profile.calories / profile.mealsPerDay;
  const mealProtein = profile.protein / profile.mealsPerDay;
  const nutrition = getTotals(base, count);
  const energy = Math.max(0, 100 - (Math.abs(nutrition.calories - mealCalories) / mealCalories) * 85);
  const protein = Math.min(100, (nutrition.protein / mealProtein) * 100);
  const fiber = Math.min(100, (nutrition.fiber / 8) * 100);
  const sugar = Math.max(0, Math.min(100, 100 - Math.max(0, nutrition.sugar - 12) * 2.5));
  const components = [energy, protein, fiber, sugar];
  let score = Math.round(components.reduce((sum, component, index) => sum + component * target.weights[index], 0));
  const styleMismatch = getStyleMismatch(getFood(base));
  if (styleMismatch) score = Math.max(0, score - 18);
  const grade = score >= 90 ? "A" : score >= 80 ? "B" : score >= 70 ? "C" : score >= 60 ? "D" : "F";
  const ratings = [
    { label: "Energy fit", score: Math.round(energy) },
    { label: "Protein", score: Math.round(protein) },
    { label: "Fiber", score: Math.round(fiber) },
    { label: "Sugar", score: Math.round(sugar) },
  ];
  return { score, grade, nutrition, styleMismatch, ratings };
}

function getReasons(base, count) {
  const { nutrition, styleMismatch } = getScore(base, count);
  const goal = goalDefaults[profile.goal];
  const mealCalories = profile.calories / profile.mealsPerDay;
  const mealProtein = profile.protein / profile.mealsPerDay;
  const calorieDifference = nutrition.calories - mealCalories;
  const calorieReason = Math.abs(calorieDifference) < mealCalories * 0.2
    ? "Energy is close to your per-meal guide."
    : `${calorieDifference > 0 ? "More" : "Less"} energy than your per-meal guide.`;
  const proteinReason = nutrition.protein >= mealProtein
    ? `Protein is on track for your ${profile.goal === "muscle" ? "muscle-building" : "daily"} focus.`
    : `About ${Math.max(1, Math.round(mealProtein - nutrition.protein))} g below your per-meal protein guide.`;
  const fiberReason = nutrition.fiber >= 7 ? "A solid source of fiber." : "Could use a little more fiber.";
  const allergenMatches = getAllergenNameMatches((getFood(base) || meals.yogurt).name);
  const reasons = styleMismatch ? [proteinReason, calorieReason, styleMismatch] : [proteinReason, calorieReason, fiberReason];
  if (allergenMatches.length) reasons.push(`Possible ${allergenMatches.join(", ")} name match; check the label.`);
  return reasons;
}

function getStyleMismatch(food) {
  if (!food || profile.diet === "anything") return "";
  const name = food.name.toLowerCase();
  const animalFoods = /\b(beef|chicken|turkey|pork|lamb|fish|salmon|tuna|shrimp|crab|milk|cheese|yogurt|egg|butter|cream)\b/;
  const meatFoods = /\b(beef|chicken|turkey|pork|lamb|fish|salmon|tuna|shrimp|crab)\b/;
  const landMeatFoods = /\b(beef|chicken|turkey|pork|lamb)\b/;
  const glutenFoods = /\b(wheat|bread|pasta|barley|rye|flour)\b/;
  if (profile.diet === "vegan" && animalFoods.test(name)) return "Possible mismatch with your vegan preference; check ingredients.";
  if (profile.diet === "vegetarian" && meatFoods.test(name)) return "Possible mismatch with your vegetarian preference.";
  if (profile.diet === "pescatarian" && landMeatFoods.test(name)) return "Possible mismatch with your pescatarian preference.";
  if (profile.diet === "gluten-free" && glutenFoods.test(name)) return "Possible wheat or gluten match; check the package.";
  if (profile.diet === "keto" && food.carbs > 15) return "Higher in carbohydrates than a lower-carb pattern may suit.";
  return "";
}

function gradeWord(grade) {
  return { A: "excellent", B: "strong", C: "moderate", D: "light", F: "low" }[grade];
}

function normalizedFoodName(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

function findCachedFood(query) {
  const normalizedQuery = normalizedFoodName(query);
  if (!normalizedQuery) return null;
  const candidates = [...Object.entries(meals), ...Object.entries(customFoods)];
  const exact = candidates.find(([, food]) => normalizedFoodName(food.name) === normalizedQuery);
  if (exact) return { id: exact[0], ...exact[1] };
  const matches = candidates.filter(([, food]) => normalizedFoodName(food.name).includes(normalizedQuery));
  return matches.length ? { id: matches[0][0], ...matches[0][1] } : null;
}

function updatePreview() {
  const query = mealNameInput.value.trim();
  const cachedMatch = manualMealEntry ? findCachedFood(query) : null;
  const base = cachedMatch?.id || mealBaseInput.value;
  const food = getFood(base) || meals.yogurt;
  const title = query || food.name;
  if (manualMealEntry && !cachedMatch) {
    $("#preview-grade").textContent = "—";
    $("#preview-score").textContent = "—";
    $("#score-gauge").setAttribute("aria-label", `Nutrition match needed for ${title}`);
    $("#score-title").innerHTML = `${escapeHTML(title)}<br /><em>needs a food match.</em>`;
    $("#score-summary").textContent = "No grade yet. Choose an actual USDA match or enter the nutrition values; the previous dropdown item will not be reused.";
    $("#score-ratings").innerHTML = "";
    $("#score-reasons").innerHTML = "";
    $("#score-note").textContent = "Your meal name alone cannot tell us its ingredients or nutrition.";
    return;
  }
  const { score, grade, nutrition, ratings } = getScore(base, portions);
  const quantityLabel = food.fdcId && food.normalized ? `${Math.round(portions * 100)} g` : `${portions} ${portions === 1 ? "portion" : "portions"}`;
  $("#preview-grade").textContent = grade;
  $("#preview-score").textContent = score;
  $("#score-gauge").setAttribute("aria-label", `${grade} grade, ${score} out of 100 for ${title}`);
  $("#score-title").innerHTML = `${escapeHTML(title)}<br /><em>${gradeWord(grade)} fit.</em>`;
  $("#score-summary").textContent = `${nutrition.calories} kcal · ${formatNutrient(nutrition.protein)} g protein · ${formatNutrient(nutrition.fiber)} g fiber, estimated for ${quantityLabel}${food.servingLabel ? ` (${food.servingLabel})` : ""}.`;
  $("#score-ratings").innerHTML = ratings.map((rating) => `<li><div><span>${rating.label}</span><strong>${rating.score}</strong></div><span class="rating-track"><span style="width:${rating.score}%"></span></span></li>`).join("");
  $("#score-reasons").innerHTML = getReasons(base, portions).map((reason) => `<li><span class="reason-dot"></span>${escapeHTML(reason)}</li>`).join("");
  $("#score-note").textContent = food.fdcId ? "USDA values are estimates for the selected record and serving." : "Demo meal estimates are illustrative, not package-label nutrition.";
}

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
}

function nutrientValue(food, nutrientId, names = []) {
  const found = (food.foodNutrients || []).find((nutrient) => nutrient.nutrientId === nutrientId || names.includes(nutrient.nutrientName));
  return found && Number.isFinite(Number(found.value)) ? Number(found.value) : 0;
}

function normalizeFoodRecord(food) {
  const size = Number(food.servingSize);
  const unit = String(food.servingSizeUnit || "").toLowerCase();
  const isGrams = size > 0 && ["g", "grm", "gram", "grams"].includes(unit);
  const scale = isGrams ? 100 / size : 1;
  const id = `fdc-${food.fdcId}`;
  const name = String(food.description || "Unnamed food").trim();
  const servingLabel = isGrams
    ? `per 100 g · normalized from ${size} g`
    : size > 0
      ? `per listed ${size} ${unit || "units"} · not normalized`
      : "USDA-reported basis · not normalized";
  return {
    id,
    fdcId: food.fdcId,
    name,
    icon: "●",
    calories: Math.round(nutrientValue(food, 1008, ["Energy"]) * scale),
    protein: Math.round(nutrientValue(food, 1003, ["Protein"]) * scale * 10) / 10,
    carbs: Math.round(nutrientValue(food, 1005, ["Carbohydrate, by difference"]) * scale * 10) / 10,
    fat: Math.round(nutrientValue(food, 1004, ["Total lipid (fat)"]) * scale * 10) / 10,
    fiber: Math.round(nutrientValue(food, 1079, ["Fiber, total dietary"]) * scale * 10) / 10,
    sugar: Math.round(nutrientValue(food, 2000, ["Sugars, total including NLEA", "Total Sugars"]) * scale * 10) / 10,
    sodium: Math.round(nutrientValue(food, 1093, ["Sodium, Na"]) * scale),
    category: String(food.foodCategory || "Food"),
    dataType: String(food.dataType || "USDA record"),
    brand: String(food.brandOwner || food.brandName || ""),
    normalized: isGrams,
    defaultPortions: isGrams ? Math.round(size / 100 * 10) / 10 : 1,
    servingLabel,
  };
}

function getAllergenNameMatches(name) {
  const patterns = {
    milk: /\b(milk|dairy|cheese|yogurt|cream|butter|whey)\b/i,
    egg: /\b(egg|albumen|mayonnaise)\b/i,
    peanut: /\b(peanut)\b/i,
    "tree nuts": /\b(almond|walnut|cashew|pecan|pistachio|hazelnut|tree nut)\b/i,
    soy: /\b(soy|soya|edamame)\b/i,
    wheat: /\b(wheat|bread|pasta|barley|rye|flour)\b/i,
    fish: /\b(fish|salmon|tuna|cod|sardine|tilapia)\b/i,
    shellfish: /\b(shellfish|shrimp|prawn|crab|lobster|clam|oyster)\b/i,
  };
  return profile.allergies.filter((allergen) => patterns[allergen]?.test(name));
}

function getFoodProperties(food) {
  const properties = [];
  if (!food.normalized) return properties;
  if (food.protein >= 20) properties.push("High protein");
  if (food.fiber >= 5) properties.push("Fiber source");
  if (food.sodium > 0 && food.sodium <= 140) properties.push("Lower sodium");
  if (food.sugar > 0 && food.sugar <= 5) properties.push("Lower sugar");
  return properties;
}

function addFoodOption(food) {
  customFoods[food.id] = food;
  if (![...mealBaseInput.options].some((option) => option.value === food.id)) {
    mealBaseInput.add(new Option(food.name, food.id));
  }
}

function renderFoodResults(foodList) {
  const results = $("#food-results");
  if (!foodList.length) {
    results.innerHTML = '<div class="food-empty">No matching records found. Try a broader food name.</div>';
    return;
  }
  results.innerHTML = foodList.map((food) => {
    const properties = getFoodProperties(food).map((property) => `<span class="food-property">${property}</span>`).join("");
    const warning = getAllergenNameMatches(food.name).map((allergen) => `<span class="food-property alert">Possible ${escapeHTML(allergen)} name match</span>`).join("");
    const brand = food.brand ? ` · ${escapeHTML(food.brand)}` : "";
    return `<article class="food-card"><div class="food-card-top"><div><h2>${escapeHTML(food.name)}</h2><span class="food-source">${escapeHTML(food.category)} · ${escapeHTML(food.dataType)}${brand}</span></div><div class="food-kcal"><strong>${food.calories}</strong>kcal</div></div><div class="food-nutrients"><div class="food-nutrient"><strong>${food.protein} g</strong>Protein</div><div class="food-nutrient"><strong>${food.carbs} g</strong>Carbs</div><div class="food-nutrient"><strong>${food.fat} g</strong>Fat</div><div class="food-nutrient"><strong>${food.fiber} g</strong>Fiber</div><div class="food-nutrient"><strong>${food.sugar} g</strong>Sugars</div><div class="food-nutrient"><strong>${food.sodium} mg</strong>Sodium</div></div><div class="food-properties">${properties}${warning || '<span class="food-property">USDA nutrient record</span>'}</div><div class="food-card-actions"><span>${escapeHTML(food.servingLabel)}</span><button class="button button-secondary" type="button" data-food-add="${escapeHTML(food.id)}">Log serving</button></div></article>`;
  }).join("");
}

async function searchUSDA(query, dataType, append = false) {
  const status = $("#food-search-status");
  const button = $("#food-search-button");
  const results = $("#food-results");
  const searchLimit = usdaApiKey === "DEMO_KEY" ? 10 : 80;
  if (foodSearchCount >= searchLimit) {
    status.textContent = `This tab has reached its ${searchLimit}-search limit for the current USDA key.`;
    results.innerHTML = "";
    $("#load-more-foods").hidden = true;
    return;
  }
  const page = append ? nextFoodPage : 1;
  if (!append) {
    lastFoodQuery = query;
    lastFoodType = dataType;
    currentFoods = [];
    nextFoodPage = 0;
    $("#load-more-foods").hidden = true;
  }
  foodSearchCount += 1;
  try {
    sessionStorage.setItem("good-measure-usda-searches", String(foodSearchCount));
  } catch {
  }
  status.textContent = "Searching USDA FoodData Central…";
  results.innerHTML = '<div class="food-loading">Looking through the food database…</div>';
  button.disabled = true;
  $("#load-more-foods").disabled = true;
  try {
    const params = new URLSearchParams({ api_key: usdaApiKey, query, pageSize: "12", pageNumber: String(page) });
    if (dataType) params.set("dataType", dataType);
    const response = await fetch(`https://api.nal.usda.gov/fdc/v1/foods/search?${params}`);
    if (!response.ok) throw new Error(response.status === 429 ? "USDA demo search limit reached. Try again later." : `USDA search returned ${response.status}.`);
    const data = await response.json();
    const pageFoods = (data.foods || []).map(normalizeFoodRecord);
    currentFoods = append ? [...currentFoods, ...pageFoods.filter((food) => !currentFoods.some((existing) => existing.id === food.id))] : pageFoods;
    nextFoodPage = Number(data.totalHits) > page * 12 || (!Number.isFinite(Number(data.totalHits)) && pageFoods.length === 12) ? page + 1 : 0;
    currentFoods.forEach(addFoodOption);
    saveStorage(storageKeys.foods, customFoods);
    renderFoodResults(currentFoods);
    status.textContent = `${currentFoods.length} records · USDA FoodData Central · ${foodSearchCount}/${searchLimit} requests used.`;
    $("#load-more-foods").hidden = !nextFoodPage;
  } catch (error) {
    results.innerHTML = '<div class="food-empty">The food database is unavailable right now. Check your connection and try again.</div>';
    status.textContent = error.message || "Food search failed.";
    $("#load-more-foods").hidden = true;
  } finally {
    button.disabled = false;
    $("#load-more-foods").disabled = false;
  }
}

function logMealEntry(base, title, count) {
  loggedMeals.unshift({ id: crypto.randomUUID(), base, title: title.slice(0, 80), portions: count });
  mealBaseInput.value = base;
  manualMealEntry = false;
  mealNameInput.value = "";
  portions = (getFood(base) || meals.yogurt).defaultPortions || 1;
  portionOutput.value = portions;
  portionOutput.textContent = portions;
  const selectedFood = getFood(base) || meals.yogurt;
  $("#portion-unit").textContent = selectedFood.fdcId && selectedFood.normalized ? "100 g units" : selectedFood.fdcId ? "Servings" : "Portions";
  persist();
  renderAll();
  $("#meal-match-area").hidden = true;
  $("#meal-match-results").innerHTML = "";
  $("#manual-meal-entry").hidden = true;
  updatePreview();
  showToast("Meal added to your day.");
}

function renderMealMatches(foodList) {
  const results = $("#meal-match-results");
  if (!foodList.length) {
    results.innerHTML = '<p class="match-empty">No USDA records matched that name. Try another name or enter the nutrition values from the package.</p>';
    $("#manual-meal-entry").hidden = false;
    return;
  }
  results.innerHTML = foodList.slice(0, 5).map((food) => {
    addFoodOption(food);
    const count = food.defaultPortions || 1;
    const { score, grade, nutrition } = getScore(food.id, count);
    return `<article class="meal-match-card"><div><h3>${escapeHTML(food.name)}</h3><p>${escapeHTML(food.dataType)} · ${escapeHTML(food.servingLabel)}</p><span>${nutrition.calories} kcal · ${formatNutrient(nutrition.protein)} g protein · ${formatNutrient(nutrition.fiber)} g fiber</span></div><div class="match-grade"><strong>${grade}</strong><small>${score}/100 fit</small></div><button class="button button-secondary" type="button" data-meal-match="${escapeHTML(food.id)}">Use and add</button></article>`;
  }).join("");
  $("#manual-meal-entry").hidden = false;
}

async function findMealMatches(query) {
  const area = $("#meal-match-area");
  const status = $("#meal-match-status");
  area.hidden = false;
  $("#manual-meal-entry").hidden = true;
  $("#meal-match-results").innerHTML = '<p class="match-empty">Searching USDA foods…</p>';
  status.textContent = `Finding nutrition records for “${query}”. Choose a matching record before it’s graded.`;
  const searchLimit = usdaApiKey === "DEMO_KEY" ? 10 : 80;
  if (foodSearchCount >= searchLimit) {
    status.textContent = "The shared USDA demo-search limit has been reached for this tab.";
    $("#meal-match-results").innerHTML = "";
    $("#manual-meal-entry").hidden = false;
    return;
  }
  foodSearchCount += 1;
  try {
    sessionStorage.setItem("good-measure-usda-searches", String(foodSearchCount));
  } catch {
  }
  try {
    const params = new URLSearchParams({ api_key: usdaApiKey, query, pageSize: "10", pageNumber: "1" });
    const response = await fetch(`https://api.nal.usda.gov/fdc/v1/foods/search?${params}`);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(response.status === 429 ? "USDA search is rate-limited right now. Enter label nutrition below or try your search again later." : `USDA search returned ${response.status}.`);
    pendingMealMatches = (data.foods || []).map(normalizeFoodRecord);
    pendingMealMatches.forEach(addFoodOption);
    saveStorage(storageKeys.foods, customFoods);
    status.textContent = pendingMealMatches.length ? "Choose the closest product or food record. Its nutrition is shown before adding." : "No exact search results. You can try another name or enter the label values.";
    renderMealMatches(pendingMealMatches);
  } catch (error) {
    status.textContent = error.message || "Food search failed.";
    $("#meal-match-results").innerHTML = "";
    $("#manual-meal-entry").hidden = false;
  }
}

function addFoodToLog(foodId, title = "") {
  const food = customFoods[foodId] || currentFoods.find((item) => item.id === foodId);
  if (!food) return;
  addFoodOption(food);
  logMealEntry(food.id, title || food.name, food.defaultPortions || 1);
}

function renderMeals() {
  const mealList = $("#meal-list");
  $("#meal-count").textContent = loggedMeals.length;
  if (!loggedMeals.length) {
    mealList.innerHTML = '<div class="empty-state">Nothing logged yet. Add a meal above to start your day.</div>';
    return;
  }
  mealList.innerHTML = loggedMeals.map((entry) => {
    const food = getFood(entry.base) || meals.yogurt;
    const { grade, nutrition } = getScore(entry.base, entry.portions);
    const portionLabel = food.fdcId && food.normalized ? `${Math.round(entry.portions * 100)} g` : `${entry.portions} ${entry.portions === 1 ? "portion" : "portions"}`;
    return `<article class="meal-item"><span class="meal-symbol" aria-hidden="true">${food.icon || "●"}</span><div><div class="meal-name">${escapeHTML(entry.title)}</div><div class="meal-meta">${portionLabel} · ${formatNutrient(nutrition.protein)} g protein · ${formatNutrient(nutrition.fiber)} g fiber${food.servingLabel ? ` · ${escapeHTML(food.servingLabel)}` : ""}</div></div><div class="meal-kcal"><strong>${nutrition.calories}</strong> kcal</div><span class="meal-grade" aria-label="Grade ${grade}">${grade}</span><button class="remove-meal" type="button" data-remove="${escapeHTML(entry.id)}" aria-label="Remove ${escapeHTML(entry.title)}">×</button></article>`;
  }).join("");
}

function renderDaily() {
  const totals = loggedMeals.reduce((sum, entry) => {
    const nutrition = getTotals(entry.base, entry.portions);
    for (const key of ["calories", "protein", "fiber"]) sum[key] += nutrition[key];
    return sum;
  }, { calories: 0, protein: 0, fiber: 0 });
  $("#calories-eaten").textContent = Math.round(totals.calories).toLocaleString();
  $("#protein-eaten").textContent = Math.round(totals.protein);
  $("#fiber-eaten").textContent = Math.round(totals.fiber);
  $("#calorie-target").textContent = profile.calories.toLocaleString();
  $("#protein-target").textContent = profile.protein;
  $("#calorie-progress").style.width = `${Math.min(100, (totals.calories / profile.calories) * 100)}%`;
  $("#protein-progress").style.width = `${Math.min(100, (totals.protein / profile.protein) * 100)}%`;
  $("#fiber-progress").style.width = `${Math.min(100, (totals.fiber / 25) * 100)}%`;
  $("#target-calories-input").value = profile.calories;
  $("#target-protein-input").value = profile.protein;
}

function renderGoal() {
  const captions = {
    muscle: "Scores give extra weight to protein and meal energy.",
    weight: "Scores lean toward meals nearer your per-meal energy guide.",
    gain: "Scores use your daily targets and current fitness focus.",
    balance: "Scores weigh energy, protein, fiber, and added-sugar estimates.",
  };
  document.querySelectorAll("[data-goal]").forEach((button) => {
    button.setAttribute("aria-pressed", String(button.dataset.goal === profile.goal));
  });
  $("#goal-caption").textContent = captions[profile.goal];
}

function setActiveTab(tabName) {
  document.querySelectorAll("[data-tab-target]").forEach((button) => {
    const active = button.dataset.tabTarget === tabName;
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", String(active));
  });
  document.querySelectorAll("[data-view]").forEach((view) => {
    const active = view.dataset.view === tabName;
    view.hidden = !active;
    view.classList.toggle("active", active);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function renderProfileForm() {
  const fields = {
    "#profile-age": profile.age,
    "#profile-height": profile.height,
    "#profile-weight": profile.weight,
    "#profile-sex": profile.sex,
    "#profile-activity": profile.activity,
    "#profile-training": profile.training,
    "#profile-meals": profile.mealsPerDay,
    "#profile-diet": profile.diet,
    "#profile-goal": profile.bodyGoal,
  };
  Object.entries(fields).forEach(([selector, value]) => { $(selector).value = value; });
  document.querySelectorAll('input[name="allergy"]').forEach((input) => { input.checked = profile.allergies.includes(input.value); });
}

function readProfileForm() {
  const ageInput = $("#profile-age").value;
  const heightInput = $("#profile-height").value;
  const weightInput = $("#profile-weight").value;
  return {
    age: ageInput ? validNumber(ageInput, 18, 100, "") : "",
    height: heightInput ? validNumber(heightInput, 120, 230, "") : "",
    weight: weightInput ? validNumber(weightInput, 35, 250, "") : "",
    sex: $("#profile-sex").value,
    activity: Number($("#profile-activity").value),
    training: Number($("#profile-training").value),
    mealsPerDay: Number($("#profile-meals").value),
    diet: $("#profile-diet").value,
    bodyGoal: $("#profile-goal").value,
    allergies: [...document.querySelectorAll('input[name="allergy"]:checked')].map((input) => input.value),
  };
}

function mapBodyGoal(goal) {
  return { maintain: "balance", muscle: "muscle", lose: "weight", gain: "gain", performance: "muscle" }[goal] || "balance";
}

function estimateProfile(profileData) {
  const { age, height, weight } = profileData;
  if (!age || !height || !weight) return null;
  const sexAdjustment = profileData.sex === "male" ? 5 : profileData.sex === "female" ? -161 : -78;
  const restingEnergy = 10 * weight + 6.25 * height - 5 * age + sexAdjustment;
  const trainingAdjustment = Math.min(140, profileData.training * 20);
  const maintenance = Math.round((restingEnergy * Number(profileData.activity) + trainingAdjustment) / 50) * 50;
  const proteinMultipliers = { muscle: [1.6, 2], lose: [1.2, 1.6], performance: [1.4, 1.8], gain: [1.4, 1.8], maintain: [1, 1.4] };
  const bounds = proteinMultipliers[profileData.bodyGoal] || proteinMultipliers.maintain;
  const proteinLow = Math.min(400, Math.round(weight * bounds[0]));
  const proteinHigh = Math.min(400, Math.round(weight * bounds[1]));
  return {
    energyLow: Math.round(maintenance * 0.9 / 50) * 50,
    energyHigh: Math.round(maintenance * 1.1 / 50) * 50,
    energyMid: maintenance,
    proteinLow,
    proteinHigh,
    proteinMid: Math.round((proteinLow + proteinHigh) / 2),
  };
}

let pendingEstimate = null;

function showProfileEstimate(profileData) {
  pendingEstimate = estimateProfile(profileData);
  const summary = $("#estimate-summary");
  const values = $("#estimate-values");
  const applyButton = $("#apply-estimate");
  if (!pendingEstimate) {
    summary.textContent = "Add age, height, and weight to see an optional daily energy estimate. Nothing is calculated until you save your profile.";
    values.hidden = true;
    applyButton.hidden = true;
    return;
  }
  summary.textContent = "A rough adult estimate using a standard resting-energy equation and your selected activity level. It is not a prescription.";
  values.innerHTML = `<div class="estimate-value"><span>Daily energy · maintenance range</span><strong>${pendingEstimate.energyLow.toLocaleString()}–${pendingEstimate.energyHigh.toLocaleString()}</strong><small> kcal/day</small></div><div class="estimate-value"><span>Protein · broad reference range</span><strong>${pendingEstimate.proteinLow}–${pendingEstimate.proteinHigh}</strong><small> g/day</small></div>`;
  values.hidden = false;
  applyButton.hidden = false;
}

function nutritionContext() {
  const parts = [`Focus: ${goalDefaults[profile.goal].label}.`, `Daily targets: ${profile.calories} kcal and ${profile.protein} g protein.`];
  if (profile.weight && profile.height && profile.age) parts.push(`Age ${profile.age}, height ${profile.height} cm, weight ${profile.weight} kg, activity factor ${profile.activity}, training ${profile.training} days per week, goal ${profile.bodyGoal}, eating style ${profile.diet}, listed avoidances: ${profile.allergies.join(", ") || "none"}.`);
  return parts.join(" ");
}

function getAllergenNameMatches(name) {
  const patterns = {
    milk: /\b(milk|dairy|cheese|yogurt|cream|butter|whey)\b/i,
    egg: /\b(egg|albumen|mayonnaise)\b/i,
    peanut: /\b(peanut)\b/i,
    "tree nuts": /\b(almond|walnut|cashew|pecan|pistachio|hazelnut|tree nut)\b/i,
    soy: /\b(soy|soya|edamame)\b/i,
    wheat: /\b(wheat|bread|pasta|barley|rye|flour)\b/i,
    fish: /\b(fish|salmon|tuna|cod|sardine|tilapia)\b/i,
    shellfish: /\b(shellfish|shrimp|prawn|crab|lobster|clam|oyster)\b/i,
  };
  return profile.allergies.filter((allergen) => patterns[allergen]?.test(name));
}

function renderAll() {
  renderGoal();
  renderMeals();
  renderDaily();
  updatePreview();
}

function persist() {
  saveStorage(storageKeys.profile, profile);
  saveStorage(storageKeys.meals, loggedMeals);
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("visible"), 2800);
}

document.querySelectorAll("[data-goal]").forEach((button) => {
  button.addEventListener("click", () => {
    if (profile.goal === button.dataset.goal) return;
    profile.goal = button.dataset.goal;
    profile.bodyGoal = { muscle: "muscle", weight: "lose", gain: "gain", balance: "maintain" }[profile.goal];
    profile.calories = goalDefaults[profile.goal].calories;
    profile.protein = goalDefaults[profile.goal].protein;
    persist();
    renderAll();
    showToast(`Focus updated to ${goalDefaults[profile.goal].label.toLowerCase()}.`);
  });
});

mealBaseInput.addEventListener("change", () => {
  const food = getFood(mealBaseInput.value) || meals.yogurt;
  mealNameInput.value = food.name;
  manualMealEntry = false;
  portions = food.fdcId ? (food.defaultPortions || 1) : 1;
  portionOutput.value = portions;
  portionOutput.textContent = portions;
  $("#portion-unit").textContent = food.fdcId && food.normalized ? "100 g units" : food.fdcId ? "Servings" : "Portions";
  updatePreview();
});
mealNameInput.addEventListener("input", () => {
  const query = mealNameInput.value.trim();
  const selectedFood = getFood(mealBaseInput.value) || meals.yogurt;
  manualMealEntry = Boolean(query && normalizedFoodName(query) !== normalizedFoodName(selectedFood.name));
  if (manualMealEntry) {
    $("#meal-match-area").hidden = true;
    $("#meal-match-results").innerHTML = "";
  }
  updatePreview();
});

$("#portion-down").addEventListener("click", () => {
  portions = Math.max(0.5, Math.round((portions - 0.5) * 10) / 10);
  portionOutput.value = portions;
  portionOutput.textContent = portions;
  updatePreview();
});
$("#portion-up").addEventListener("click", () => {
  portions = Math.min(5, Math.round((portions + 0.5) * 10) / 10);
  portionOutput.value = portions;
  portionOutput.textContent = portions;
  updatePreview();
});

document.querySelectorAll("[data-pick]").forEach((button) => {
  button.addEventListener("click", () => {
    mealBaseInput.value = button.dataset.pick;
    mealNameInput.value = meals[button.dataset.pick].name;
    manualMealEntry = false;
    updatePreview();
    mealNameInput.focus();
  });
});

mealForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const title = mealNameInput.value.trim();
  if (manualMealEntry) {
    const cachedMatch = findCachedFood(title);
    if (cachedMatch) {
      addFoodOption(cachedMatch);
      logMealEntry(cachedMatch.id, title, cachedMatch.defaultPortions || 1);
    } else {
      await findMealMatches(title);
    }
    return;
  }
  const base = mealBaseInput.value;
  const food = getFood(base) || meals.yogurt;
  logMealEntry(base, title || food.name, portions);
});

$("#meal-match-results").addEventListener("click", (event) => {
  const button = event.target.closest("[data-meal-match]");
  if (button) addFoodToLog(button.dataset.mealMatch, mealNameInput.value.trim());
});

$("#save-manual-meal").addEventListener("click", () => {
  const name = mealNameInput.value.trim();
  const calories = Number($("#manual-calories").value);
  if (!name || !Number.isFinite(calories) || calories <= 0) {
    showToast("Enter the meal name and its calories per serving first.");
    return;
  }
  const readValue = (selector) => validNumber($(selector).value || 0, 0, 10000, 0);
  const food = {
    id: `manual-${crypto.randomUUID()}`,
    name,
    icon: "●",
    calories,
    protein: readValue("#manual-protein"),
    carbs: readValue("#manual-carbs"),
    fat: readValue("#manual-fat"),
    fiber: readValue("#manual-fiber"),
    sugar: readValue("#manual-sugar"),
    sodium: readValue("#manual-sodium"),
    servingLabel: "per serving · user-entered",
    defaultPortions: 1,
    normalized: false,
  };
  addFoodOption(food);
  saveStorage(storageKeys.foods, customFoods);
  logMealEntry(food.id, name, 1);
});

$("#meal-list").addEventListener("click", (event) => {
  const removeButton = event.target.closest("[data-remove]");
  if (!removeButton) return;
  loggedMeals = loggedMeals.filter((entry) => entry.id !== removeButton.dataset.remove);
  persist();
  renderAll();
  showToast("Meal removed.");
});

$("#clear-log").addEventListener("click", () => {
  if (!loggedMeals.length) return showToast("Your meal log is already clear.");
  loggedMeals = [];
  persist();
  renderAll();
  showToast("Today's meal log was cleared.");
});

$("#save-targets").addEventListener("click", () => {
  const calories = Number($("#target-calories-input").value);
  const protein = Number($("#target-protein-input").value);
  if (!Number.isFinite(calories) || calories < 800 || calories > 6000 || !Number.isFinite(protein) || protein < 20 || protein > 400) {
    showToast("Enter energy between 800–6,000 kcal and protein between 20–400 g.");
    return;
  }
  profile.calories = Math.round(calories);
  profile.protein = Math.round(protein);
  persist();
  renderAll();
  showToast("Your daily targets have been saved.");
});

const dateLabel = new Intl.DateTimeFormat(undefined, { weekday: "long", month: "long", day: "numeric" }).format(new Date());
$("#today-label").textContent = dateLabel.toUpperCase();
$("#log-date").textContent = new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date());
portionOutput.value = portions;
Object.values(customFoods).forEach(addFoodOption);
const defaultFood = getFood(mealBaseInput.value) || meals.yogurt;
$("#portion-unit").textContent = defaultFood.fdcId && defaultFood.normalized ? "100 g units" : defaultFood.fdcId ? "Servings" : "Portions";
$("#load-more-foods").hidden = true;
renderAll();
renderProfileForm();

document.querySelectorAll("[data-tab-target]").forEach((button) => {
  button.addEventListener("click", () => setActiveTab(button.dataset.tabTarget));
});

$("#food-search-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const query = $("#food-query").value.trim();
  if (query) searchUSDA(query, $("#food-data-type").value);
});

$("#use-usda-key").addEventListener("click", () => {
  const key = $("#usda-api-key").value.trim();
  if (!key) {
    showToast("Paste your own FoodData Central API key first.");
    return;
  }
  usdaApiKey = key;
  foodSearchCount = 0;
  try {
    sessionStorage.setItem("good-measure-usda-searches", "0");
  } catch {
  }
  $("#usda-api-key").value = "";
  $("#food-search-status").textContent = "Your key is active in this tab only. Search when ready.";
  showToast("Your USDA key is active for this tab and was not saved.");
});

$("#load-more-foods").addEventListener("click", () => {
  if (lastFoodQuery && nextFoodPage) searchUSDA(lastFoodQuery, lastFoodType, true);
});

$("#food-results").addEventListener("click", (event) => {
  const button = event.target.closest("[data-food-add]");
  if (button) addFoodToLog(button.dataset.foodAdd);
});

$("#profile-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const formProfile = readProfileForm();
  const previousGoal = profile.goal;
  profile = { ...profile, ...formProfile, goal: mapBodyGoal(formProfile.bodyGoal) };
  if (profile.goal !== previousGoal) {
    profile.calories = goalDefaults[profile.goal].calories;
    profile.protein = goalDefaults[profile.goal].protein;
  }
  persist();
  renderAll();
  renderProfileForm();
  showToast("Your profile has been saved on this device.");
});

$("#estimate-profile").addEventListener("click", () => showProfileEstimate(readProfileForm()));

$("#apply-estimate").addEventListener("click", () => {
  if (!pendingEstimate) return;
  const formProfile = readProfileForm();
  profile = { ...profile, ...formProfile, goal: mapBodyGoal(formProfile.bodyGoal) };
  profile.calories = validNumber(pendingEstimate.energyMid, 800, 6000, profile.calories);
  profile.protein = validNumber(pendingEstimate.proteinMid, 20, 400, profile.protein);
  persist();
  renderAll();
  showToast("Estimate added to today's guide. You can edit it anytime.");
});

$("#clear-profile").addEventListener("click", () => {
  profile = { ...profileDefaults, allergies: [] };
  pendingEstimate = null;
  saveStorage(storageKeys.profile, profile);
  renderProfileForm();
  showProfileEstimate(profile);
  renderAll();
  showToast("Your saved profile was cleared.");
});

function appendChatMessage(text, role) {
  const bubble = document.createElement("div");
  bubble.className = `chat-message ${role === "user" ? "user-message" : "assistant-message"}`;
  bubble.textContent = text;
  $("#chat-messages").append(bubble);
  bubble.scrollIntoView({ block: "nearest" });
  return bubble;
}

function localAssistantReply(message) {
  const normalized = message.toLowerCase();
  const lastTurn = localAssistantTurns.at(-1);
  const latestMeal = loggedMeals[0];
  const currentFood = latestMeal ? getFood(latestMeal.base) : (findCachedFood(mealNameInput.value.trim()) || getFood(mealBaseInput.value));
  const foodLabel = latestMeal?.title || currentFood?.name || "your selected meal";
  let answer;

  if (/allerg|allergen|ingredient|intoleran/.test(normalized)) {
    answer = "The app can flag possible matches in a food name, but it does not read the full ingredient list or detect cross-contamination. Verify the package label and ask a qualified professional about allergy risks.";
  } else if (/suggest|what (should|can) i eat|meal idea|recommend/.test(normalized)) {
    const candidates = [...Object.entries(meals), ...Object.entries(customFoods)]
      .map(([id, food]) => ({ id, food, ...getScore(id, food.defaultPortions || 1) }))
      .sort((left, right) => right.score - left.score)
      .slice(0, 3);
    const ideas = candidates.map(({ food, grade, score }) => `${food.name} (${grade}, ${score}/100)`).join("; ");
    answer = `For your ${goalDefaults[profile.goal].label.toLowerCase()} focus, the current demo foods that score highest are: ${ideas}. These are only comparisons from this small list; use Food library to search a specific product.`;
  } else if (/score|grade|rating|number|estimate|why/.test(normalized)) {
    const activeBase = latestMeal?.base || (findCachedFood(mealNameInput.value.trim())?.id || mealBaseInput.value);
    const activeCount = latestMeal?.portions || portions;
    const { score, grade, ratings } = getScore(activeBase, activeCount);
    const breakdown = ratings.map((rating) => `${rating.label.toLowerCase()} ${rating.score}`).join(", ");
    answer = `${foodLabel} is currently ${grade} (${score}/100) against your ${goalDefaults[profile.goal].label.toLowerCase()} focus. Its factor ratings are ${breakdown}. The formula compares the selected food record with your targets; the letter is a demo estimate, not a medical or universal food-quality rating.`;
  } else if (/improve|better|change|swap|add to/.test(normalized)) {
    const activeBase = latestMeal?.base || (findCachedFood(mealNameInput.value.trim())?.id || mealBaseInput.value);
    const { ratings } = getScore(activeBase, latestMeal?.portions || portions);
    const lowFactors = ratings.filter((rating) => rating.score < 70).map((rating) => rating.label.toLowerCase());
    answer = lowFactors.length
      ? `For ${foodLabel}, the lowest-scoring factors right now are ${lowFactors.join(" and ")}. A different portion or a complementary food may shift the comparison; log the actual combination to see the updated estimate.`
      : `${foodLabel} has no especially low factor in the current comparison. You can still compare a different portion or look for a food with more of the nutrients you want.`;
  } else if (/more|tell me|that|it|follow.?up/.test(normalized) && lastTurn) {
    answer = `Following up on “${lastTurn.question}”: we were looking at ${foodLabel} for your ${goalDefaults[profile.goal].label.toLowerCase()} focus. The current record reports ${getTotals(latestMeal?.base || mealBaseInput.value, latestMeal?.portions || portions).calories} kcal; choosing another match or portion will recalculate the displayed ratings.`;
  } else if (/pizza|yogurt|salmon|tofu|oat|burger|pasta|rice|salad|chicken|soup/.test(normalized)) {
    const matchedFood = findCachedFood(normalized.match(/pizza|yogurt|salmon|tofu|oat|burger|pasta|rice|salad|chicken|soup/)?.[0] || normalized);
    answer = matchedFood
      ? `${matchedFood.name} is available in your cached foods. Its record shows ${matchedFood.calories} kcal, ${formatNutrient(matchedFood.protein)} g protein, and ${formatNutrient(matchedFood.fiber)} g fiber ${matchedFood.servingLabel || "per demo serving"}. Select it in the meal form to see its current grade.`
      : `I don't have a nutrition record for that food in this browser yet. Type its name in the meal form and choose “Add or find match” to search USDA, then compare the results before logging it.`;
  } else {
    answer = `I’m following your ${goalDefaults[profile.goal].label.toLowerCase()} focus. I can compare ${foodLabel}, explain its factor ratings, suggest foods from the available list, or help you find a USDA match. What would you like to explore next?`;
  }

  localAssistantTurns.push({ question: message, answer });
  localAssistantTurns = localAssistantTurns.slice(-12);
  return answer;
}

async function askGemini(message) {
  const model = $("#gemini-model").value.trim() || "gemini-2.5-flash";
  const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const profileContext = $("#share-profile").checked ? ` The user explicitly opted to share this profile: ${nutritionContext()}` : "";
  assistantHistory.push({ role: "user", parts: [{ text: message }] });
  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": assistantApiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: `You are a general wellness meal-planning assistant. Be kind, concise, and non-judgmental. Discuss food ideas and explain nutrient estimates, but do not diagnose, treat a medical condition, recommend severe restriction or weight-loss targets, or claim a meal grade is medically validated. Ask users with allergies or medical concerns to verify labels and consult qualified professionals. State uncertainty about food-database values. Profile context is private and must only be used for this answer if included below; do not infer missing health details.${profileContext}` }] },
        contents: assistantHistory,
        generationConfig: { maxOutputTokens: 350 },
      }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error?.message || `Gemini returned ${response.status}. Check the model name and API key.`);
    const reply = data.candidates?.[0]?.content?.parts?.map((part) => part.text || "").join("").trim();
    if (!reply) throw new Error("Gemini returned no text. Try rephrasing your question.");
    assistantHistory.push({ role: "model", parts: [{ text: reply }] });
    return reply;
  } catch (error) {
    assistantHistory.pop();
    throw error;
  }
}

async function sendAssistantMessage(text) {
  appendChatMessage(text, "user");
  const sendButton = $("#assistant-form button");
  const input = $("#assistant-input");
  const thinking = appendChatMessage("Thinking…", "assistant");
  sendButton.disabled = true;
  try {
    thinking.textContent = assistantApiKey ? await askGemini(text) : localAssistantReply(text);
  } catch (error) {
    thinking.textContent = error.message || "The assistant is unavailable. Try again in a moment.";
  } finally {
    sendButton.disabled = false;
    input.focus();
  }
}

$("#assistant-launch").addEventListener("click", () => {
  const panel = $("#assistant-panel");
  panel.hidden = !panel.hidden;
  $("#assistant-launch").setAttribute("aria-expanded", String(!panel.hidden));
  if (!panel.hidden) $("#assistant-input").focus();
});

$("#assistant-close").addEventListener("click", () => {
  $("#assistant-panel").hidden = true;
  $("#assistant-launch").setAttribute("aria-expanded", "false");
  $("#assistant-launch").focus();
});

$("#connect-gemini").addEventListener("click", () => {
  const key = $("#gemini-api-key").value.trim();
  const model = $("#gemini-model").value.trim() || "gemini-2.5-flash";
  if (!/^[a-zA-Z0-9._-]+$/.test(model)) {
    showToast("Model names can contain letters, numbers, dots, hyphens, and underscores.");
    return;
  }
  assistantApiKey = key;
  assistantHistory = [];
  const status = $("#assistant-status");
  const statusDot = document.querySelector(".assistant-status-dot");
  status.textContent = assistantApiKey ? `Connected · ${model}` : "Local demo · connect Gemini for AI";
  statusDot.classList.toggle("connected", Boolean(assistantApiKey));
  $("#gemini-api-key").value = "";
  showToast(assistantApiKey ? "Gemini connected. Your key stays in this tab's memory." : "Gemini disconnected.");
});

$("#assistant-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const input = $("#assistant-input");
  const message = input.value.trim();
  if (!message) return;
  input.value = "";
  sendAssistantMessage(message);
});

document.querySelectorAll("[data-prompt]").forEach((button) => {
  button.addEventListener("click", () => sendAssistantMessage(button.dataset.prompt));
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !$("#assistant-panel").hidden) {
    $("#assistant-panel").hidden = true;
    $("#assistant-launch").setAttribute("aria-expanded", "false");
    $("#assistant-launch").focus();
  }
});